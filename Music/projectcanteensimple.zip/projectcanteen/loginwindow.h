#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include <QMainWindow>

class LoginWindow : public QMainWindow {
    Q_OBJECT

public:
    LoginWindow();
    bool initializeDatabase();
private slots:
    void onLoginClicked();

private:
    bool connectToDatabase();
    bool validateLogin(const QString &username, const QString &password);
};

#endif // LOGINWINDOW_H
