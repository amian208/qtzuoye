#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    setWindowTitle("食堂菜品选择系统");
    resize(400, 300);

    canteenComboBox = new QComboBox(this);
    dishListWidget = new QListWidget(this);
    commentLineEdit = new QLineEdit(this);
    submitCommentButton = new QPushButton("提交评论", this);
    commentsListWidget = new QListWidget(this);
    searchLineEdit = new QLineEdit(this);
    searchButton = new QPushButton("搜索", this);
    setupDatabase();
    loadCanteens();
    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(canteenComboBox);
    layout->addWidget(dishListWidget);
    layout->addWidget(searchLineEdit);
    layout->addWidget(searchButton);
    layout->addWidget(commentLineEdit);
    layout->addWidget(submitCommentButton);
    layout->addWidget(commentsListWidget);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(layout);
    setCentralWidget(centralWidget);

    connect(canteenComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &MainWindow::onCanteenSelected);
    connect(submitCommentButton, &QPushButton::clicked, this, &MainWindow::onSubmitComment);
    connect(searchButton, &QPushButton::clicked, this, &MainWindow::onSearchDish);
    connect(dishListWidget, &QListWidget::currentRowChanged, this, &MainWindow::onDisplayComments);


    loadCanteensFromDatabase();

}

void MainWindow::onCanteenSelected(int index) {
    int canteenId = canteenComboBox->currentData().toInt();
    loadDishesForCanteen(canteenId);
    dishListWidget->clear();

    QSqlQuery query;
    query.prepare("SELECT DishName FROM entries WHERE LocationID IN (SELECT LocationID FROM location WHERE CanteenID = :canteenId)");
    query.bindValue(":canteenId", canteenId);
    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", "查询菜品失败: " + query.lastError().text());
        return;
    }

    while (query.next()) {
        QString dishName = query.value(0).toString();
        dishListWidget->addItem(dishName);
    }
}
void MainWindow::onDisplayComments() {
    if (!dishListWidget->currentItem()) {
        return;
    }

    QString dishName = dishListWidget->currentItem()->text();
    commentsListWidget->clear();

    QSqlQuery query;
    query.prepare("SELECT CommentText FROM comments WHERE DishID = (SELECT DishID FROM entries WHERE DishName = :dishName)");
    query.bindValue(":dishName", dishName);

    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", "加载评论失败: " + query.lastError().text());
        return;
    }

    while (query.next()) {
        QString comment = query.value(0).toString();
        commentsListWidget->addItem(comment);
    }
}

void MainWindow::onSubmitComment() {
    if (!dishListWidget->currentItem()) {
        QMessageBox::warning(this, "警告", "请选择一个菜品");
        return;
    }

    QString dishName = dishListWidget->currentItem()->text();
    QString comment = commentLineEdit->text();

    QSqlQuery query;
    query.prepare("INSERT INTO comments (DishID, UserID, CommentText) VALUES ((SELECT DishID FROM entries WHERE DishName = :dishName), 1, :comment)"); // 假设UserID为1
    query.bindValue(":dishName", dishName);
    query.bindValue(":comment", comment);

    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", "提交评论失败: " + query.lastError().text());
    }

    onDisplayComments();
    commentLineEdit->clear();
}

void MainWindow::setupDatabase() {
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("pkudb");

    if (!db.open()) {
        QMessageBox::critical(this, "数据库错误", "无法打开数据库: " + db.lastError().text());
        return;
    }
}

void MainWindow::loadCanteens() {
    QSqlQuery query;
    if (!query.exec("SELECT CanteenID, CanteenName FROM canteens")) {
        QMessageBox::critical(this, "数据库错误", "加载食堂失败: " + query.lastError().text());
        return;
    }

    canteenComboBox->clear(); // 清除之前的选项
    while (query.next()) {
        int canteenId = query.value(0).toInt();
        QString canteenName = query.value(1).toString();
        canteenComboBox->addItem(canteenName, canteenId); // 将食堂ID作为用户数据存储
    }
}
void MainWindow::loadCanteensFromDatabase() {
    QSqlQuery query;
    if (!query.exec("SELECT CanteenID, CanteenName FROM canteens")) {
        QMessageBox::critical(this, "数据库错误3", "加载食堂失败3: " + query.lastError().text());
        return;
    }

    while (query.next()) {
        int canteenId = query.value(0).toInt();
        QString canteenName = query.value(1).toString();
        canteens.append(Canteen(canteenId, canteenName));
        canteenComboBox->addItem(canteenName, canteenId);
    }
}

void MainWindow::loadDishesForCanteen(int canteenId) {
    QSqlQuery query;
    query.prepare("SELECT DishID, DishName, Price, TasteID, Calories, ImageSRC, LocationID FROM entries WHERE LocationID IN (SELECT LocationID FROM location WHERE CanteenID = :canteenId)");
    query.bindValue(":canteenId", canteenId);
    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", "查询菜品失败: " + query.lastError().text());
        return;
    }

    dishes.clear(); // Clear previous dishes
    dishListWidget->clear();

    while (query.next()) {
        int dishId = query.value(0).toInt();
        QString dishName = query.value(1).toString();
        int price = query.value(2).toInt();
        QString tasteId = query.value(3).toString();
        int calories = query.value(4).toInt();
        QString imageSrc = query.value(5).toString();
        QString locationId = query.value(6).toString();

        dishes.append(Dish(dishId, dishName, price, tasteId, calories, imageSrc, locationId));
        dishListWidget->addItem(dishName);
    }
}
void MainWindow::onSearchDish() {
    QString searchText = searchLineEdit->text();
    dishListWidget->clear();

    QSqlQuery query;
    query.prepare("SELECT DishID, DishName, Price, TasteID, Calories, ImageSRC, LocationID FROM entries WHERE DishName LIKE :searchText");
    query.bindValue(":searchText", "%" + searchText + "%");

    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", "搜索菜品失败: " + query.lastError().text());
        return;
    }

    dishes.clear(); // Clear previous dishes

    while (query.next()) {
        int dishId = query.value(0).toInt();
        QString dishName = query.value(1).toString();
        int price = query.value(2).toInt();
        QString tasteId = query.value(3).toString();
        int calories = query.value(4).toInt();
        QString imageSrc = query.value(5).toString();
        QString locationId = query.value(6).toString();

        dishes.append(Dish(dishId, dishName, price, tasteId, calories, imageSrc, locationId));
        dishListWidget->addItem(dishName);
    }
}
