CREATE DATABASE  IF NOT EXISTS `pku` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `pku`;
-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: pku
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `canteens`
--

DROP TABLE IF EXISTS `canteens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `canteens` (
  `CanteenID` text,
  `CanteenName` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `canteens`
--

LOCK TABLES `canteens` WRITE;
/*!40000 ALTER TABLE `canteens` DISABLE KEYS */;
INSERT INTO `canteens` VALUES ('pku_jiayuan','Jiayuan'),('pku_nongyuan','Nongyuan'),('pku_yannan','Yannan');
/*!40000 ALTER TABLE `canteens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `DishID` int DEFAULT NULL,
  `DishName` text,
  `Price` int DEFAULT NULL,
  `TasteID` text,
  `Calories` int DEFAULT NULL,
  `ImageID` text,
  `LocationID` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (1,'Sichuan Peppercorn Mixed Grain Fish Noodles',15,'spicy_low',400,'img_src1','pku_00001'),(2,'Tomato Mixed Grain Fish Noodles',15,'normal',350,'img_src2','pku_00001'),(3,'Spicy Mixed Grain Fish Noodles',15,'spicy_high',450,'img_src3','pku_00001'),(4,'Small Pot Sichuan Peppercorn Instant Noodles',10,'spicy_low',300,'img_src4','pku_00001'),(5,'Small Pot Braised Instant Noodles',10,'normal',320,'img_src5','pku_00001'),(6,'Old Beijing Sauerkraut Instant Noodles',10,'sour',300,'img_src6','pku_00001'),(7,'Small Pot Potato Noodles',13,'spicy_low',350,'img_src7','pku_00001'),(8,'Small Pot Bone Broth Rice Noodles',12,'normal',300,'img_src8','pku_00001'),(9,'Oil Splashed Noodles',8,'spicy_low',400,'img_src9','pku_00001'),(10,'Fried Sauce Noodles',10,'salty',350,'img_src10','pku_00001'),(11,'Small Pot Chicken Noodles',12,'unknown',400,'img_src11','pku_00001'),(12,'Spicy Fish Fillet with Tofu',16,'spicy_high',450,'img_src12','pku_00002'),(13,'Sichuan Peppercorn Fish Fillet with Tofu',16,'spicy_low',400,'img_src13','pku_00002'),(14,'Sichuan Peppercorn Pork Fillet with Tofu',14,'spicy_low',380,'img_src14','pku_00002'),(15,'Spicy Pork Fillet with Tofu',14,'spicy_high',400,'img_src15','pku_00002'),(16,'Sichuan Peppercorn Chicken Fillet with Tofu',13,'spicy_low',350,'img_src16','pku_00002'),(17,'Spicy Chicken Fillet with Tofu',13,'spicy_high',370,'img_src17','pku_00002'),(18,'Spicy Beef with Tofu',18,'spicy_high',500,'img_src18','pku_00002'),(19,'Sichuan Peppercorn Beef with Tofu',18,'spicy_low',480,'img_src19','pku_00002'),(20,'Minced Meat with Tofu',9,'normal',300,'img_src20','pku_00002'),(21,'Sichuan Peppercorn Intestines with Tofu',18,'spicy_low',450,'img_src21','pku_00002'),(22,'Spicy Intestines with Tofu',18,'spicy_high',470,'img_src22','pku_00002'),(23,'Sichuan Peppercorn Chicken',14,'spicy_low',400,'img_src23','pku_00003'),(24,'Sichuan Peppercorn Fish Fillet',15,'spicy_low',420,'img_src24','pku_00003'),(25,'Boiled Pork Slices',16,'spicy_high',500,'img_src25','pku_00003'),(26,'Boiled Fish',21,'spicy_high',520,'img_src26','pku_00003'),(27,'Boiled Beef',16,'spicy_high',480,'img_src27','pku_00003'),(28,'Boiled Chicken Slices',16,'spicy_high',450,'img_src28','pku_00003'),(29,'Bowl Chicken',18,'spicy_low',400,'img_src29','pku_00003'),(30,'Bowl Chicken (Small Portion)',13,'spicy_low',300,'img_src30','pku_00003'),(31,'Minnan Flat Dumplings',8,'normal',250,'img_src31','pku_00004'),(32,'Beef Soup Rice Noodles (Clear Soup + Satay)',16,'normal',400,'img_src32','pku_00004'),(33,'Beef Flat Noodles (Clear Soup + Satay)',16,'normal',450,'img_src33','pku_00004'),(34,'Scallion Oil Chicken Leg Mixed Noodles',14,'salty',500,'img_src34','pku_00004'),(35,'Scallion Oil Pork Elbow Mixed Noodles',15,'salty',550,'img_src35','pku_00004'),(36,'Scallion Oil Braised Pork Mixed Noodles',13,'salty',600,'img_src36','pku_00004'),(37,'Egg Custard Char Siu Rice',12,'sweet',550,'img_src37','pku_00005'),(38,'Crispy Skin Roast Duck Rice',13,'salty',600,'img_src38','pku_00005'),(39,'White Cut Chicken Rice',13,'salty',500,'img_src39','pku_00005'),(40,'Crispy Chicken Leg Rice',14,'salty',650,'img_src40','pku_00005'),(41,'Honey Glazed Chicken Wings Rice',15,'sweet',700,'img_src41','pku_00005'),(42,'Stone Pot Waxed Meat Rice',15,'salty',750,'img_src42','pku_00005'),(43,'Shenzhen Roast Goose Rice',16,'salty',800,'img_src43','pku_00005'),(44,'Stone Pot Black Bean Spare Ribs Rice',16,'salty',850,'img_src44','pku_00005'),(45,'Tomato Sauce Chicken Cutlet',13,'salty',500,'img_src45','pku_00005'),(46,'Honey Glazed Char Siu Rice',17,'sweet',700,'img_src46','pku_00005'),(47,'Braised Tofu Rice',10,'salty',350,'img_src47','pku_00005'),(48,'Shredded Pork Fried Rice Noodles',12,'salty',500,'img_src48','pku_00005'),(49,'Dragon Bone Soup',5,'normal',150,'img_src49','pku_00005'),(50,'Egg Custard Char Siu',8,'sweet',300,'img_src50','pku_00005'),(51,'Honey Glazed Chicken Wings',6,'sweet',250,'img_src51','pku_00005'),(52,'Crispy Chicken Leg (Half)',6,'salty',325,'img_src52','pku_00005'),(53,'Stir-fried Bell Pepper and Egg with Sauce (Mixed Rice/Noodles)',10,'spicy_high',450,'img_src53','pku_00006'),(54,'Double-cooked Pork (Mixed Rice/Noodles)',12,'salty',550,'img_src54','pku_00006'),(55,'Big Plate Chicken Mixed Noodles (Mixed Rice/Noodles)',10,'spicy_high',650,'img_src55','pku_00006'),(56,'Pepper and Sesame Chicken (Mixed Rice/Noodles)',13,'spicy_high',700,'img_src56','pku_00006'),(57,'Beef Sauce (Mixed Rice/Noodles)',13,'salty',600,'img_src57','pku_00006'),(58,'Black Pepper Potato Beef Steak',15,'spicy_high',750,'img_src58','pku_00006'),(59,'Stir-fried Lamb with Scallions (Mixed Rice/Noodles)',17,'salty',800,'img_src59','pku_00006'),(60,'Cilantro Beef (Mixed Rice/Noodles)',18,'salty',850,'img_src60','pku_00006'),(61,'Naan (Piece)',2,'normal',200,'img_src61','pku_00006'),(62,'Lamb Offal Soup',6,'normal',150,'img_src62','pku_00006'),(63,'Iron Plate Instant Noodles',9,'salty',450,'img_src63','pku_00006'),(64,'Milk Red Bean Porridge',3,'sweet',150,'img_src64','pku_00006'),(65,'Dry-fried Noodles',13,'salty',600,'img_src65','pku_00006'),(66,'Lanzhou Hand-pulled Noodles',15,'normal',550,'img_src66','pku_00006'),(67,'Sour Cabbage Braised Lamb',15,'salty',700,'img_src67','pku_00006'),(68,'Xinjiang Hand-grab Rice',16,'salty',750,'img_src68','pku_00006'),(69,'Iron Plate Squid Tentacles',12,'salty',350,'img_src69','pku_00006'),(70,'Iron Plate Squid',10,'salty',300,'img_src70','pku_00006'),(71,'Grilled Buns',5,'salty',250,'img_src71','pku_00006'),(72,'Honey Glazed Chicken Wings',6,'sweet',250,'img_src72','pku_00006'),(73,'Grilled Fish Tofu',2,'salty',150,'img_src73','pku_00006'),(74,'Grilled Duck Leg',8,'salty',400,'img_src74','pku_00006'),(75,'Grilled Lamb Leg',29,'salty',850,'img_src75','pku_00006'),(76,'Toona Sprouts Stir-fried Eggs',12,'spicy_low',150,'img_src76','pku_00007'),(77,'Dry-braised Tilapia',8,'spicy_high',300,'img_src77','pku_00007'),(78,'Dry Pot Instant Noodles',12,'spicy_low',350,'img_src78','pku_00007'),(79,'Potato Braised Beef',18,'spicy_low',450,'img_src79','pku_00007'),(80,'Dry Fried Chicken Steak',13,'spicy_low',400,'img_src80','pku_00007'),(81,'Dry Pot Baby Cabbage',8,'spicy_high',200,'img_src81','pku_00007'),(82,'Egg Soup',1,'normal',50,'img_src82','pku_00007'),(83,'Stone Pot Bibimbap',10,'spicy_low',600,'img_src83','pku_00008'),(84,'Tomato Scrambled Eggs Bibimbap',11,'normal',400,'img_src84','pku_00008'),(85,'Chicken Bibimbap',12,'normal',500,'img_src85','pku_00008'),(86,'Bacon Bibimbap',13,'spicy_low',600,'img_src86','pku_00008'),(87,'Pork Belly Bibimbap',15,'spicy_low',700,'img_src87','pku_00008'),(88,'Teriyaki Sausage Bibimbap',16,'spicy_low',600,'img_src88','pku_00008'),(89,'Eel Bibimbap',18,'spicy_high',500,'img_src89','pku_00008'),(90,'Tuna Hand-grab Rice',18,'spicy_low',400,'img_src90','pku_00008'),(91,'Pork Floss Baked Sushi',13,'normal',350,'img_src91','pku_00008'),(92,'Cheese Baked Sushi',15,'normal',400,'img_src92','pku_00008'),(93,'Seaweed Soup',3,'normal',50,'img_src93','pku_00008'),(94,'Korean Rice Cakes',7,'spicy_low',300,'img_src94','pku_00008'),(95,'Shin Ramen',11,'spicy_low',500,'img_src95','pku_00008'),(96,'Black Pepper Ribs Bibimbap',16,'normal',600,'img_src96','pku_00008'),(97,'Grilled Pork Belly Bibimbap',16,'spicy_high',700,'img_src97','pku_00008'),(98,'Beef Bibimbap',18,'normal',600,'img_src98','pku_00008'),(99,'Fish Fillet Congee',7,'normal',200,'img_src99','pku_00009'),(100,'Crispy Egg Fried Rice',12,'spicy_low',400,'img_src100','pku_00009'),(101,'Pineapple Hand-grab Pie',5,'spicy_low',250,'img_src101','pku_00009'),(102,'Teriyaki Chicken Leg Rice',14,'normal',500,'img_src102','pku_00009'),(103,'Xiamen Fried Noodles',10,'normal',400,'img_src103','pku_00009'),(104,'Taiwanese Three-cup Chicken Rice',13,'normal',600,'img_src104','pku_00009'),(105,'Steamed Ribs Rice',18,'normal',600,'img_src105','pku_00009'),(106,'Taiwanese Braised Pork Rice',13,'normal',600,'img_src106','pku_00009'),(107,'Curry Chicken Cutlet Rice',13,'normal',700,'img_src107','pku_00009'),(108,'Soybean Pork Skin Trotter Rice',18,'normal',700,'img_src108','pku_00009'),(109,'Pork Knuckle Rice',17,'normal',600,'img_src109','pku_00009'),(110,'Braised Beef Steak Rice',20,'spicy_high',700,'img_src110','pku_00009'),(111,'Minced Meat with Pepper and Eggplant Rice',11,'spicy_mid',500,'img_src111','pku_00009'),(112,'Crispy Duck Rice',13,'normal',600,'img_src112','pku_00009');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `LocationID` text,
  `CuisineName` text,
  `CanteenID` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES ('pku_00001','Regional Flavored Noodles','pku_jiayuan'),('pku_00002','Hubei and Hunan Tofu Series','pku_jiayuan'),('pku_00003','Hubei and Hunan Flavors','pku_jiayuan'),('pku_00004','Fujian','pku_jiayuan'),('pku_00005','Guangdong','pku_jiayuan'),('pku_00006','Xinjiang','pku_jiayuan'),('pku_00007','Sichuan and Hunan Flavors','pku_jiayuan'),('pku_00008','Japanese and Korean Flavors','pku_jiayuan'),('pku_00009','Minnan Flavors','pku_jiayuan');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taste`
--

DROP TABLE IF EXISTS `taste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taste` (
  `TasteID` text,
  `TasteName` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taste`
--

LOCK TABLES `taste` WRITE;
/*!40000 ALTER TABLE `taste` DISABLE KEYS */;
INSERT INTO `taste` VALUES ('normal','Normal'),('spicy_low','Mild Spicy'),('spicy_mid','Moderate Spicy'),('spicy_high','Spicy'),('salty','Salty'),('sweet','Sweet'),('sour','Sour'),('unknown','-');
/*!40000 ALTER TABLE `taste` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-30 16:38:18
