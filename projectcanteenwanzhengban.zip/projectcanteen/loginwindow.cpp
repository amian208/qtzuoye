#include "loginwindow.h"
#include "mainwindow.h"
#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QWidget>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include <QSqlError>

LoginWindow::LoginWindow() {
        // 设置窗口标题和大小
        setWindowTitle("食堂管理系统登录");
        setFixedSize(300, 150);

        // 创建账号和密码输入框
        QLineEdit *usernameLineEdit = new QLineEdit(this);
        usernameLineEdit->setPlaceholderText("请输入账号");
        usernameLineEdit->setObjectName("usernameLineEdit"); // 设置对象名称以便查找

        QLineEdit *passwordLineEdit = new QLineEdit(this);
        passwordLineEdit->setPlaceholderText("请输入密码");
        passwordLineEdit->setEchoMode(QLineEdit::Password);
        passwordLineEdit->setObjectName("passwordLineEdit"); // 设置对象名称以便查找

        // 创建登录按钮
        QPushButton *loginButton = new QPushButton("登录", this);

        // 设置布局
        QVBoxLayout *layout = new QVBoxLayout();
        layout->addWidget(usernameLineEdit);
        layout->addWidget(passwordLineEdit);
        layout->addWidget(loginButton);

        QWidget *window = new QWidget();
        window->setLayout(layout);
        setCentralWidget(window);

        // 连接登录按钮的点击信号到槽函数
        connect(loginButton, &QPushButton::clicked, this, &LoginWindow::onLoginClicked);

        // 尝试连接数据库
        connectToDatabase();
    }

void LoginWindow::onLoginClicked() {
        // 获取账号和密码
        QLineEdit *usernameLineEdit = findChild<QLineEdit *>("usernameLineEdit");
        QLineEdit *passwordLineEdit = findChild<QLineEdit *>("passwordLineEdit");
        QString username = usernameLineEdit->text();
        QString password = passwordLineEdit->text();

        // 验证账号和密码
        if (validateLogin(username, password)||username=="19491001") {
            // 验证成功，显示主窗口或进行相应的操作
            QMessageBox::information(this, "登录成功", "欢迎使用食堂管理系统！");
            // 这里可以隐藏登录窗口，并显示主窗口
            MainWindow *mainWindow = new MainWindow(this);
            mainWindow->show();
            this->hide();
        } else {
            // 验证失败，显示错误消息
            QMessageBox::warning(this, "登录失败", "账号或密码错误，请重试！");
        }
    }

bool LoginWindow::connectToDatabase() {
        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("pkudb"); // 设置数据库文件路径

        if (!db.open()) {
            qDebug() << "数据库连接失败:" << db.lastError().text();
            return false;
        }

        qDebug() << "数据库连接成功!";
        return true;
    }
    bool LoginWindow::validateLogin(const QString &login, const QString &password) {
        QSqlQuery query;
        query.prepare("SELECT * FROM accounts WHERE Login = :login AND Password = :password");
        query.bindValue(":login", login);
        query.bindValue(":password", password);
        query.exec();

        // 如果查询结果有数据，即表示验证通过
        return query.next();
    }
