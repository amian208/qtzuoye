#ifndef CANTEEN_H
#define CANTEEN_H
#include <QMainWindow>

#endif // CANTEEN_H
class Canteen {
public:
    int canteenId;
    QString canteenName;

    Canteen(int id, const QString& name) : canteenId(id), canteenName(name) {}
};
class Dish {
public:
    int dishId;
    QString dishName;
    int price;
    QString tasteId;
    int calories;
    QString imageSrc;
    QString locationId;

    Dish(int id, const QString& name, int p, const QString& tId, int cal, const QString& img, const QString& locId)
        : dishId(id), dishName(name), price(p), tasteId(tId), calories(cal), imageSrc(img), locationId(locId) {}
};
