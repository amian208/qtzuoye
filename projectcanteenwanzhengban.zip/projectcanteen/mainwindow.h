#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<canteen.h>
#include <QMainWindow>
#include <QComboBox>
#include <QListWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QMessageBox>
#include <QSqlError>

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

private slots:
    void onCanteenSelected(int index);
    void onSubmitComment();
    void loadCanteens();
    void onDisplayComments();
    void onSearchDish();

private:
    QComboBox *canteenComboBox;
    QListWidget *dishListWidget;
    QLineEdit *commentLineEdit;
    QPushButton *submitCommentButton;
    QListWidget *commentsListWidget;
    QLineEdit *searchLineEdit;
    QPushButton *searchButton;
    void setupDatabase();
    QVector<Canteen> canteens;
    QVector<Dish> dishes;
    void loadCanteensFromDatabase();
    void loadDishesForCanteen(int canteenId);
    void displayDishComments(const QString& dishName);
};

#endif // MAINWINDOW_H
